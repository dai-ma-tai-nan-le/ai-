This project was developed by Julian Bilcke (@jbilcke-hf), as part of his work at Hugging Face.

------------------------------------------

A huge thanks to external developers for their contributions! 

艾逗笔 (@idoubi):
- [feature] Added support for OpenAI: https://github.com/jbilcke-hf/ai-comic-factory/pull/6
- [bug] predict import error (use dynamic imports for the LLM provider): https://github.com/jbilcke-hf/ai-comic-factory/pull/9

