
export const pick = (items: string[]) => items[Math.floor(Math.random()*items.length)]
