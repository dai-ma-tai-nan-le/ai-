export function computePercentage(input: string | number) {
  // TODO something
  return 0
}