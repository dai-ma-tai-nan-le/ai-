
// the NSFW has to contain bad words, but doing so might get the code flagged
// or attract unwanted attention, so we hash them
export const forbidden = [
  // TODO implement this
]